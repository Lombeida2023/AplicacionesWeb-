</div>
</body>
<footer>
    <p>&copy; <?= date('Y') ?> Mi Sitio Web. Todos los derechos reservados.</p>
</footer>

</html>