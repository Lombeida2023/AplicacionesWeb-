<?php
$title = "Sobre mi";
require __DIR__ . '/../../resources/about.template.php';
?>