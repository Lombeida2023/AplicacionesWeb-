<?php require __DIR__ . '/partials/header.php'; ?>

<section class="text-center py-20 bg-gradient-to-b from-pink-50 to-white">
   <h1 class="text-5xl font-bold text-pink-700 mb-6">
      Proyecto de Aplicaciones Web
   </h1>

   <p class="text-lg text-gray-600 max-w-3xl mx-auto mb-10">
      Este sitio forma parte de una práctica académica enfocada en el uso de PHP para la manipulación de arreglos bidimensionales,
      renderizado dinámico de datos y separación entre la lógica del controlador y la vista.
   </p>

   <div class="flex justify-center gap-4">
      <a href="/links" class="bg-pink-500 text-white px-6 py-3 rounded-full shadow hover:bg-pink-600 transition">
         Ver enlaces por categoría 💕
      </a>

      <a href="/post" class="bg-purple-200 text-purple-800 px-6 py-3 rounded-full hover:bg-purple-300 transition">
         Ver artículo del proyecto
      </a>
   </div>
</section>

<section class="py-20">
   <div class="max-w-5xl mx-auto grid md:grid-cols-3 gap-8 text-center">
      
      <div class="p-8 bg-white rounded-2xl shadow-md border border-pink-100">
         <h3 class="text-xl font-semibold text-pink-600 mb-3">📚 Organización de Datos</h3>
         <p class="text-gray-600 text-sm">
            Uso de arreglos bidimensionales para estructurar enlaces por categorías.
         </p>
      </div>

      <div class="p-8 bg-white rounded-2xl shadow-md border border-purple-100">
         <h3 class="text-xl font-semibold text-purple-600 mb-3">⚙️ Lógica y Presentación</h3>
         <p class="text-gray-600 text-sm">
            Separación entre controlador y vista siguiendo un patrón tipo MVC.
         </p>
      </div>

      <div class="p-8 bg-white rounded-2xl shadow-md border border-pink-100">
         <h3 class="text-xl font-semibold text-pink-600 mb-3">💡 PHP Dinámico</h3>
         <p class="text-gray-600 text-sm">
            Renderizado dinámico de contenido HTML usando estructuras de control.
         </p>
      </div>

   </div>
</section>

<?php require __DIR__ . '/partials/footer.php'; ?>
